                                <div class="modal fade text-start show" id="modal_global" tabindex="-1"  role="dialog" aria-hidden="true" >
                                    <div class="modal-dialog modal-{{$size ?? 'lg'}} modal-dialog-centered">
                                        <div class="modal-content">

                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel1">{{$title ?? 'Default Title'}}</h4>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>

                                            <div class="modal-body">

                                            </div>
                                        </div>
                                    </div>
                                </div>

