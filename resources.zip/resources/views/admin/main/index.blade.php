@extends('admin.layout.index')

@section('content')

              <!-- Advanced Search -->
              <section id="advanced-search-datatable">
                <div class="row">
                  <div class="col-12">
                    <div class="card">
                      <div class="card-header border-bottom">
                        <h4 class="card-title">Dashboard</h4>
                      </div>
                      <!--Search Form -->
                      <div class="card-body mt-2">
                        Welcome to Backoffice App
                      </div>

                    </div>
                  </div>
                </div>
              </section>
              <!--/ Advanced Search -->
@endsection


@section('js')
<script>

</script>
@endsection
