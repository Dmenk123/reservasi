<div class="col-12">
    <div class="card card-transaction">
        <div class="card-body">
            {{-- <h4 class="card-title">Bukti Pembayaran</h4> --}}
            <img src="{{asset('storage/'.$old->t_reservasi_det->original)}}" height="400" width="100%" alt="Bukti Pembayaran" />
        </div>
    </div>
</div>
