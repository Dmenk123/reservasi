<iframe src="{{route('admin.t_create_qrcode.qr_in', ['id_t_qrcode' => request()->get('id_t_qrcode'), 'tipe_t_qrcode' => request()->get('tipe_t_qrcode')])}}"
    height="700"
    width="100%">
</iframe>
