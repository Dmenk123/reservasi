<tr>
    <td colspan="6"><strong>X. Catatan Lainnya</strong></td>
  </tr>
  <tr>
    <td colspan="6">
        <p><strong>{{__('step_other_notes.label.pernah_daftar')}}</strong></p>

        <p>{{$old->note_applied_another_branch}}</p>
    </td>
  </tr>
</table>
