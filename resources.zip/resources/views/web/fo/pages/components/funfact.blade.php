 <!-- Start Fun Fact Section -->
 <div class="st-funfact-wrap st-section-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-6">
          <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
            <div class="st-funfact-icon"><i class="flaticon-rate"></i></div>
            <h2 class="st-funfact-number st-counter">999</h2>
            <h3 class="st-funfact-title">Satisfied customers</h3>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.25s">
            <div class="st-funfact-icon"><i class="flaticon-code"></i></div>
            <h2 class="st-funfact-number st-counter">185</h2>
            <h3 class="st-funfact-title">Built websites</h3>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
            <div class="st-funfact-icon"><i class="flaticon-laptop"></i></div>
            <h2 class="st-funfact-number st-counter">100</h2>
            <h3 class="st-funfact-title">Experts Worker</h3>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.35s">
            <div class="st-funfact-icon"><i class="flaticon-win"></i></div>
            <h2 class="st-funfact-number st-counter">200</h2>
            <h3 class="st-funfact-title">Experience Years</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Fun Fact Section -->
