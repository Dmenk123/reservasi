 <!-- Start About Section -->
 <div class="st-about-wrap st-section-top" id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="st-vertical-middle">
            <div class="st-vertical-middle-in">
              <div class="st-about-img wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.2s"><img src="{{asset('assets/fo/img/light-img/about-img1.png')}}" alt="demo"></div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="st-section-heading st-style1">
            <h3>About Us</h3>
            <h2>We are awesome team work for your business dream</h2>
          </div>
          <div class="st-about-text">
            <p>Business is the activity of making one's living or making money. One business makes a commercial transaction with another. A business entity is an entity that is formed and administered as per corporate.</p>
            <ul class="tr-list">
              <li>One's business To attend to one's duties.</li>
              <li>Business may refer to many differing activities.</li>
              <li>Business representation made by and for business people.</li>
              <li>Business information about a company or individual.</li>
            </ul>
            <a href="#" class="st-btn st-style1 st-size1 st-color2">Get More Info!</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End About Section -->
