<!-- Start Footer Seciton -->
<footer class="st-site-footer st-style1 st-sticky-footer">
    <div class="st-main-footer text-center">
      <div class="container">
        <div class="st-footer-logo">
          <img src="{{asset('assets/fo/img/light-img/footer-logo.png')}}" alt="demo">
        </div>
        <div class="st-footer-text"> tesWe understand that it is better to morph virally than to embrace intuitively.<br>
          We will matrix the power of schemas to redefine.</div>
        <div class="st-footer-social">
          <ul class="st-footer-social-btn st-flex st-mp0">
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="st-copyright text-center">
        <div class="st-copyright-text">© Cipto Djunaedy, 2022.</div>
    </div>
  </footer>
  <!-- End Footer Seciton -->
