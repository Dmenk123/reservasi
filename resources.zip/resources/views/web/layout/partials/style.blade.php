 <!-- Custom CSS -->
 <link rel="stylesheet" href="{{asset('assets/fo/css/styles.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/custom.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/animation.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/bootstrap.min.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/snackbar.min.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/slick.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/slick-theme.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/themify.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/line-icons.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/iconfont.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/font-awesome.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/flaticon.css')}}" />
 <link rel="stylesheet" href="{{asset('assets/fo/css/plugins/sweetalert2.min.css')}}" />
 
 <link rel="stylesheet" href="{{asset('assets/fo/fullcalendar/fullcalendar.css')}}" />
 

 {{-- <link href="assets/css/styles.css" rel="stylesheet"> --}}