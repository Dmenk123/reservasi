<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->

<script src="{{asset('assets/fo/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/fo/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/fo/js/slick.js')}}"></script>
<script src="{{asset('assets/fo/js/slider-bg.js')}}"></script>
<script src="{{asset('assets/fo/js/smoothproducts.js')}}"></script>
<script src="{{asset('assets/fo/js/snackbar.min.js')}}"></script>
<script src="{{asset('assets/fo/js/moment.min.js')}}"></script>
<script src="{{asset('assets/fo/js/jQuery.style.switcher.js')}}"></script>
<script src="{{asset('assets/fo/js/custom.js')}}"></script>
<script src="{{asset('assets/fo/js/sweetalert2.all.min.js')}}"></script>
<script src="{{asset('assets/fo/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{asset('assets/fo/fullcalendar/fullcalendar.js')}}"></script>
<script src="{{asset('assets/fo/fullcalendar/locale-all.js')}}"></script>
<script type="text/javascript"
src="https://app.sandbox.midtrans.com/snap/snap.js"
data-client-key="SB-Mid-client-x38IIWfIatfALj7-"></script>

@yield('custom_js')
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->		