@extends('web.layout.index')

@section('content')
<div class="col-xl-12 col-md-12 col-12">
    <div class="card card-statistics">
      <div class="card-body statistics-body">
        <div class="row">



        </div>
    </div>
  </div>
</div>
@endsection
