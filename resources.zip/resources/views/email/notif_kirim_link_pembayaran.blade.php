<!DOCTYPE html>
<html>
<head>
    <title>Invitation Test</title>
</head>
<body>

    <h1>This is test mail from Tutsmake.com</h1>
    <p>Laravel 8 send email example</p>
    <p>Thank you</p>
</body>
</html>
