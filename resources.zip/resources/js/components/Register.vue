<template>
  <div>
    <h1>Halaman Register</h1>
  </div>
</template>