<template>
  <Layout>
    Add page content here
  </Layout>
</template>

<script>
    export default {
        mounted() {
            console.log('layout mounted.')
        }
    }
</script>