<?php
return [
    'not_found' => 'Page Not Found - 404',
    'not_found_desc' => 'We\'re Sorry, it looks like the URL address entered is invalid or expired.',
    'btn_home' => 'Back to Home',
];