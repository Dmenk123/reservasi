<?php
return [
    'berhasil_simpan' => 'Data Saved',
    'berhasil_simpan_resume' => 'Your preferences has been updated. Now you will be redirected back to main page',
    'berhasil_update' => 'Data Updated',
    'berhasil_register' => 'Account registration is successful, please confirm via the email we have sent ',
    'berhasil_hapus' => 'Data deleted',

    'swal_warning' => 'Please correct your input form',
    'swal_error' => "Server Error. Please contact our administrator",
    'swal_confirm_delete' => "Apakah Anda yakin menghapus data ini ?",
];
