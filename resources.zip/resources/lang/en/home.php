<?php
return [
    'perusahaan_kami' => 'Our Companies',
];
