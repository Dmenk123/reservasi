<?php
return [
    'title' => 'Other Notes',
    'description' => 'Other Notes',
    'label' => [
        'pernah_daftar' => 'Did You have participated in the recruitment process at pramita branches / other places ? please mention and explain below',
    ],
    'button' => [
        'next' => 'Next',
        'prev' => 'Previous',
    ],
    'validation' => [
        'pernah_daftar_required' => 'Please choose one',
    ],
];
