<?php

return [
    'home' => 'Home',
    'buka_lowongan' => 'Job Vacancies',
    'profil_lowongan' => 'Job Profile',
    'perusahaan' => 'Companies',
    'panduan' => 'User Guide',
    'register' => 'Register',
    'login' => 'Login',
    'data_list' => 'My Applications',
    'online_test' => 'Ujian Online',
];
