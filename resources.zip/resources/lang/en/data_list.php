<?php
return [
    'judul' => 'My Application History',
    'label' => [
        'nama' => 'Candidate Name',
        'profesi' => 'Desired Profession',
        'cabang' => 'Destination Branch',
        'dibuat' => 'Data Created at',
        'status' => 'Waiting for verification',
        'status_yes' => 'The file has been successfully verified and meets the requirements',
        'status_no' => 'Sorry, at this time you are not in our qualifications. ',
    ],
    'selengkapnya' => 'Read More',
    'kembali' => 'Back to Index',
    'pdf' => 'Print as PDF',
];
