<?php
return [
    'perusahaan_kami' => 'Perusahaan Kami',
];
