<?php

return [
    'home' => 'Beranda',
    'buka_lowongan' => 'Lowongan Kerja',
    'profil_lowongan' => 'Profil Lowongan',
    'perusahaan' => 'Perusahaan',
    'panduan' => 'Panduan',
    'register' => 'Register',
    'login' => 'Login',
    'data_list' => 'Data Saya',
    'online_test' => 'Ujian Online',
];
