<?php
return [
    'not_found' => 'Halaman Yang Anda Cari Tidak Ditemukan - 404',
    'not_found_desc' => 'Kami Mohon Maaf, sepertinya alamat URL yang dimasukkan tidak valid atau kadaluwarsa.',
    'btn_home' => 'Kembali ke Halaman Utama',
];