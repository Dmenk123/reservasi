<?php
return [
    'title' => 'Catatan Lainnya',
    'description' => 'Catatan Lainnya',
    'label' => [
        'pernah_daftar' => 'Pernah mengikuti proses recruitment di cabang pramita / tempat lain ?  Sebutkan dan Jelaskan.        ',
    ],
    'button' => [
        'next' => 'Selanjutnya',
        'prev' => 'Sebelumnya',
    ],
    'validation' => [
        'pernah_daftar_required' => 'Please choose one',
    ],
];
