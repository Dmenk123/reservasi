<?php
return [
    'berhasil_simpan' => 'Berhasil Menyimpan Data',
    'berhasil_simpan_resume' => 'Preferensi Anda berhasil diupdate. Anda akan diarahkan kembali menuju halaman utama',
    'berhasil_update' => 'Berhasil Meng-update Data',
    'berhasil_register' => 'Proses registrasi akun berhasil, silahkan melakukan konfirmasi melalui email yang telah kami kirimkan',
    'berhasil_hapus' => 'Berhasil menghapus data',

    'swal_warning' => 'Mohon periksa kembali inputan Anda',
    'swal_error' => "Server Error. Harap menghubungi administrator atau coba lagi nanti",
    'swal_confirm_delete' => "Are you sure you want to delete this data ?",
];
